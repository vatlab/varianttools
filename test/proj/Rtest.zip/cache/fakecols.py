#!/usr/bin/env python
from random import choice
import sys
if len(sys.argv)<2:
	print("./fakecols.py NUM < input > output")
	sys.exit(0)
input = [x.split() for x in sys.stdin.readlines()]
output = [x[0:4] for x in input]
output = ['\t'.join(x)+'\t'+str(choice(range(int(sys.argv[1])))) if idx > 0 else '\t'.join(x)+'\tgroup' for idx, x in enumerate(output)]
for item in output:
    print item
