###
# snv
###

#dat=read.table("dat.R.asso.txt",header=TRUE,sep="\t")

testSnv <- function(dat) {
    #attach(dat[,1:4])
    maf <- apply(dat[,5:ncol(dat)], 2, function(x) sum(x, na.rm=TRUE)) / (apply(dat[,5:ncol(dat)], 2, function(x) sum(!is.na(x))) * 2)
    tval=vector()
    pval=vector()
    estimate=vector()
    for(i in 5:ncol(dat)) {
        snp = if (maf[i-4] > 0.5) 2-dat[,i] else dat[,i]
        asso=lm(BMI~snp+aff+sex, data=dat)
        tryCatch ( {
            tval[i-4]=summary(asso)$coefficients["snp","t value"]
            pval[i-4]=summary(asso)$coefficients["snp","Pr(>|t|)"]
            estimate[i-4]=summary(asso)$coefficients["snp","Estimate"]
        }, error=function(e) {
            tval[i-4] = NA; pval[i-4]=NA; estimate[i-4]=NA;
        }
        )
    }
    output=cbind(ID=names(dat)[5:ncol(dat)],tval,pval,estimate)
    output=output[order(output[,1]),]
    write.table(output, stdout() ,quote=FALSE,row.names=FALSE,sep="\t")
}

###
# group_by
###

#first calculate maf then group
#dat=read.table("dat.R.group.txt",header=TRUE,sep="\t")

scoreRegion <- function(dat) {
    maf=apply(dat[1:nrow(dat),c(-1,-2)], 1, function(x) sum(x, na.rm=TRUE)) / (apply(dat[1:nrow(dat),c(-1,-2)], 1, function(x) sum(!is.na(x))) * 2)
    for (i in 1:nrow(dat)) {
        if (maf[i] > 0.5) dat[i,c(-1,-2)] = 2 - dat[i,c(-1,-2)]
    }
    head=c(min(dat[,2]):max(dat[,2]))
    group=data.frame()
    for (j in min(dat[,2]):max(dat[,2])) {
        if (j>min(dat[,2])) group=cbind(group, apply(dat[which(dat[,2]==j),c(-1,-2)], 2, sum))
        else group=data.frame(apply(dat[which(dat[,2]==j),c(-1,-2)], 2, sum))
    }
    colnames(group)=head
    snps = dat[,c(-1,-2)]
    write.table(group, stdout(), quote=FALSE,sep="\t")
}


###
# region
###

#assocation by group in R
#dat=read.table("dat.R.grysum.txt",header=TRUE,sep="\t")

testRegion <- function(dat) {
    tval=vector()
    pval=vector()
    estimate=vector()
    for(i in 5:ncol(dat)) {
        snp=dat[,i]
        asso=lm(BMI~snp+aff+sex, data=dat)
        tryCatch ( {
            tval[i-4]=summary(asso)$coefficients["snp","t value"]
            pval[i-4]=summary(asso)$coefficients["snp","Pr(>|t|)"]
            estimate[i-4]=summary(asso)$coefficients["snp","Estimate"]
        }, error=function(e) {
            tval[i-4] = NA; pval[i-4]=NA; estimate[i-4]=NA;
        }
        )
    }
    output=cbind(ID=names(dat)[5:ncol(dat)],tval,pval,estimate)
    if (nrow(output)>1) output=output[order(output[,1]),]
    write.table(output, stdout(), quote=FALSE,row.names=FALSE,sep="\t")
}


###
# main
###

argsv <- commandArgs(trailingOnly = TRUE)
dat <- read.table(pipe('cat /dev/stdin'), header=TRUE, sep = "\t")
for (i in argsv) get(i)(dat)
