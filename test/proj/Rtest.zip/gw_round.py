#!/usr/bin/env python
import fileinput, sys
sep = '\t'
try:
    sep = sys.argv[1]
except:
    pass
#
for line in fileinput.input():
    try:
        line = line.split(sep)
        for i in range(len(line)):
            try:
                line[i] = int(line[i])
            except:
                pass
            try:
                line[i] = float(line[i])
            except:
                pass
        print(sep.join(['{0:G}'.format(x, precision=5) if isinstance(x, float) else str(x) for x in line]).replace('\n',''))
    except IOError:
        sys.exit(0)
